//
//  SearchedWordsCell.swift
//  Pixabay
//
//  Created by Vivek Singh Mehta on 10/02/21.
//

import UIKit

class SearchedWordsCell: UITableViewCell {

    //MARK:- Outlets
    @IBOutlet weak var cellLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
