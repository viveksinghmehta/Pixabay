//
//  FullScreenImageCell.swift
//  Pixabay
//
//  Created by WishACloud on 11/02/21.
//

import UIKit

class FullScreenImageCell: UICollectionViewCell {

    @IBOutlet weak var fullScreenImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
